export default function Checkout() {
  return (
    <div className="container mx-auto px-4 py-16 text-center">
      <h1 className="text-3xl font-bold mb-4">Checkout</h1>
      <p className="text-muted-foreground">
        Checkout functionality will be implemented here
      </p>
    </div>
  );
}
