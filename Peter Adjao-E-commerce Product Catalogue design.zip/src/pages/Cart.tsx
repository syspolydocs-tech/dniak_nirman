import { Link } from "react-router";

export default function Cart() {
  return (
    <div className="container mx-auto px-4 py-16 text-center">
      <h1 className="text-3xl font-bold mb-4">Shopping Cart</h1>
      <p className="text-muted-foreground mb-8">
        Your cart functionality will be implemented here
      </p>
      <Link to="/books" className="text-primary hover:underline">
        Continue Shopping
      </Link>
    </div>
  );
}
