import { useState, useMemo } from "react";
import { useNavigate } from "react-router";
import { ProductCard } from "../components/ProductCard";
import { FilterPanel } from "../components/FilterPanel";
import { SortDropdown, SortOption } from "../components/SortDropdown";
import { Button } from "../components/ui/button";
import { Filter, Grid, List } from "lucide-react";
import { Sheet, SheetContent, SheetTrigger } from "../components/ui/sheet";
import { toast } from "sonner@2.0.3";
import { mockBooks } from "../data/mockData";
import { useAuth } from "../contexts/AuthContext";

interface FilterState {
  categories: string[];
  priceRange: [number, number];
  minRating: number;
}

export default function Books() {
  const navigate = useNavigate();
  const { isAuthenticated } = useAuth();
  const [filters, setFilters] = useState<FilterState>({
    categories: [],
    priceRange: [0, 100],
    minRating: 0,
  });
  const [sortBy, setSortBy] = useState<SortOption>("featured");
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");

  // Convert books to product format for existing components
  const booksAsProducts = mockBooks.map(book => ({
    id: book.id,
    name: book.title,
    price: book.price,
    originalPrice: book.originalPrice,
    rating: book.rating,
    reviewCount: book.reviewCount,
    image: book.image,
    category: book.category.toLowerCase(),
    isNew: book.isNew,
    isSale: book.isSale,
    salePercentage: book.salePercentage,
  }));

  // Filter products
  const filteredProducts = useMemo(() => {
    return booksAsProducts.filter((product) => {
      // Category filter
      if (
        filters.categories.length > 0 &&
        !filters.categories.includes(product.category)
      ) {
        return false;
      }

      // Price filter
      if (
        product.price < filters.priceRange[0] ||
        product.price > filters.priceRange[1]
      ) {
        return false;
      }

      // Rating filter
      if (product.rating < filters.minRating) {
        return false;
      }

      return true;
    });
  }, [booksAsProducts, filters]);

  // Sort products
  const sortedProducts = useMemo(() => {
    const products = [...filteredProducts];

    switch (sortBy) {
      case "price-asc":
        return products.sort((a, b) => a.price - b.price);
      case "price-desc":
        return products.sort((a, b) => b.price - a.price);
      case "rating":
        return products.sort((a, b) => b.rating - a.rating);
      case "newest":
        return products.sort((a, b) => {
          if (a.isNew && !b.isNew) return -1;
          if (!a.isNew && b.isNew) return 1;
          return 0;
        });
      default:
        return products;
    }
  }, [filteredProducts, sortBy]);

  const handleFilterChange = (newFilters: FilterState) => {
    setFilters(newFilters);
  };

  const handleAddToCart = (bookId: string) => {
    if (!isAuthenticated) {
      toast.error("Please login to purchase books", {
        action: {
          label: "Login",
          onClick: () => navigate("/login"),
        },
      });
      return;
    }
    toast.success("Book added to cart!");
  };

  const handleWishlistToggle = (bookId: string) => {
    toast.success("Wishlist updated!");
  };

  const handleBuyNow = (bookId: string) => {
    if (!isAuthenticated) {
      navigate("/login", { state: { from: `/books/${bookId}` } });
      return;
    }
    navigate("/checkout");
  };

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Page Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Browse Books</h1>
        <p className="text-muted-foreground">
          Discover your next great read from our extensive collection
        </p>
      </div>

      <div className="flex flex-col lg:flex-row gap-6">
        {/* Desktop Filters - Sidebar */}
        <aside className="hidden lg:block w-64 flex-shrink-0">
          <div className="sticky top-24">
            <FilterPanel filters={filters} onFilterChange={handleFilterChange} />
          </div>
        </aside>

        {/* Main Content */}
        <div className="flex-1">
          {/* Toolbar */}
          <div className="flex items-center justify-between mb-6 gap-4 flex-wrap">
            <div className="flex items-center gap-2">
              {/* Mobile Filter Button */}
              <Sheet>
                <SheetTrigger asChild>
                  <Button variant="outline" className="lg:hidden">
                    <Filter className="h-4 w-4 mr-2" />
                    Filters
                  </Button>
                </SheetTrigger>
                <SheetContent side="left" className="w-80 overflow-y-auto">
                  <FilterPanel
                    filters={filters}
                    onFilterChange={handleFilterChange}
                  />
                </SheetContent>
              </Sheet>

              <span className="text-sm text-muted-foreground">
                {sortedProducts.length} books found
              </span>
            </div>

            <div className="flex items-center gap-2">
              {/* Sort Dropdown */}
              <SortDropdown value={sortBy} onChange={setSortBy} />

              {/* View Toggle */}
              <div className="hidden sm:flex border rounded-md">
                <Button
                  variant={viewMode === "grid" ? "default" : "ghost"}
                  size="sm"
                  onClick={() => setViewMode("grid")}
                  className="rounded-r-none"
                >
                  <Grid className="h-4 w-4" />
                </Button>
                <Button
                  variant={viewMode === "list" ? "default" : "ghost"}
                  size="sm"
                  onClick={() => setViewMode("list")}
                  className="rounded-l-none"
                >
                  <List className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>

          {/* Products Grid */}
          {sortedProducts.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-muted-foreground text-lg">
                No books found matching your filters.
              </p>
              <Button
                variant="outline"
                className="mt-4"
                onClick={() =>
                  setFilters({
                    categories: [],
                    priceRange: [0, 100],
                    minRating: 0,
                  })
                }
              >
                Clear Filters
              </Button>
            </div>
          ) : (
            <div
              className={
                viewMode === "grid"
                  ? "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
                  : "flex flex-col gap-4"
              }
            >
              {sortedProducts.map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  onAddToCart={handleAddToCart}
                  onWishlistToggle={handleWishlistToggle}
                  onBuyNow={handleBuyNow}
                />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
