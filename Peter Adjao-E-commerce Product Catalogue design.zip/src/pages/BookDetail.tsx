import { useParams, useNavigate, Link } from "react-router";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { Card, CardContent } from "../components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import { Star, ShoppingCart, Heart, ArrowLeft, BookOpen, Calendar } from "lucide-react";
import { mockBooks } from "../data/mockData";
import { useState } from "react";
import { toast } from "sonner@2.0.3";
import { useAuth } from "../contexts/AuthContext";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";

export default function BookDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { isAuthenticated } = useAuth();
  const [isWishlisted, setIsWishlisted] = useState(false);

  const book = mockBooks.find(b => b.id === id);

  if (!book) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <h1 className="text-2xl font-bold mb-4">Book Not Found</h1>
        <Button onClick={() => navigate("/books")}>Back to Books</Button>
      </div>
    );
  }

  const handleBuyNow = () => {
    if (!isAuthenticated) {
      navigate("/login", { state: { from: `/books/${id}` } });
      return;
    }
    toast.success("Book added to cart!");
    navigate("/cart");
  };

  const handleAddToCart = () => {
    if (!isAuthenticated) {
      toast.error("Please login to purchase books", {
        action: {
          label: "Login",
          onClick: () => navigate("/login"),
        },
      });
      return;
    }
    toast.success("Book added to cart!");
  };

  const toggleWishlist = () => {
    setIsWishlisted(!isWishlisted);
    toast.success(isWishlisted ? "Removed from wishlist" : "Added to wishlist");
  };

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Back Button */}
      <Button variant="ghost" onClick={() => navigate("/books")} className="mb-6">
        <ArrowLeft className="h-4 w-4 mr-2" />
        Back to Books
      </Button>

      <div className="grid md:grid-cols-2 gap-8 mb-12">
        {/* Book Image */}
        <div>
          <Card className="overflow-hidden">
            <ImageWithFallback
              src={book.image}
              alt={book.title}
              className="w-full h-[600px] object-cover"
            />
          </Card>
        </div>

        {/* Book Details */}
        <div>
          <div className="flex gap-2 mb-3">
            {book.isNew && (
              <Badge variant="secondary" className="bg-green-500 text-white">
                NEW
              </Badge>
            )}
            {book.isSale && (
              <Badge variant="destructive">
                SALE {book.salePercentage}% OFF
              </Badge>
            )}
            <Badge variant="outline">{book.category}</Badge>
          </div>

          <h1 className="text-4xl font-bold mb-2">{book.title}</h1>
          <p className="text-xl text-muted-foreground mb-4">by {book.author}</p>

          {/* Rating */}
          <div className="flex items-center gap-2 mb-6">
            <div className="flex">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  className={`h-5 w-5 ${
                    i < Math.floor(book.rating)
                      ? "text-yellow-400 fill-current"
                      : "text-gray-300"
                  }`}
                />
              ))}
            </div>
            <span className="text-lg font-semibold">{book.rating}</span>
            <span className="text-muted-foreground">({book.reviewCount} reviews)</span>
          </div>

          {/* Price */}
          <div className="flex items-center gap-3 mb-6">
            <span className="text-4xl font-bold">${book.price}</span>
            {book.originalPrice && (
              <span className="text-xl text-muted-foreground line-through">
                ${book.originalPrice}
              </span>
            )}
          </div>

          {/* Description */}
          <p className="text-lg mb-6 leading-relaxed">{book.description}</p>

          {/* Book Info */}
          <div className="grid grid-cols-2 gap-4 mb-6 p-4 bg-muted/50 rounded-lg">
            {book.pages && (
              <div>
                <p className="text-sm text-muted-foreground">Pages</p>
                <p className="font-semibold">{book.pages}</p>
              </div>
            )}
            {book.publisher && (
              <div>
                <p className="text-sm text-muted-foreground">Publisher</p>
                <p className="font-semibold">{book.publisher}</p>
              </div>
            )}
            {book.publishedDate && (
              <div>
                <p className="text-sm text-muted-foreground">Published</p>
                <p className="font-semibold">{book.publishedDate}</p>
              </div>
            )}
            {book.isbn && (
              <div>
                <p className="text-sm text-muted-foreground">ISBN</p>
                <p className="font-semibold text-xs">{book.isbn}</p>
              </div>
            )}
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3 mb-4">
            <Button size="lg" className="flex-1" onClick={handleBuyNow}>
              <ShoppingCart className="h-5 w-5 mr-2" />
              Buy Now
            </Button>
            <Button size="lg" variant="outline" className="flex-1" onClick={handleAddToCart}>
              Add to Cart
            </Button>
            <Button
              size="lg"
              variant="outline"
              onClick={toggleWishlist}
              className={isWishlisted ? "bg-red-50" : ""}
            >
              <Heart className={`h-5 w-5 ${isWishlisted ? "fill-red-500 text-red-500" : ""}`} />
            </Button>
          </div>

          <p className="text-sm text-muted-foreground">
            Free shipping on orders over $50 • Easy returns
          </p>
        </div>
      </div>

      {/* Tabs Section */}
      <Tabs defaultValue="description" className="w-full">
        <TabsList className="w-full justify-start">
          <TabsTrigger value="description">Description</TabsTrigger>
          <TabsTrigger value="details">Details</TabsTrigger>
          <TabsTrigger value="reviews">Reviews</TabsTrigger>
        </TabsList>

        <TabsContent value="description" className="mt-6">
          <Card>
            <CardContent className="pt-6">
              <h3 className="text-xl font-semibold mb-4">About This Book</h3>
              <p className="text-muted-foreground leading-relaxed">
                {book.description}
              </p>
              <p className="text-muted-foreground leading-relaxed mt-4">
                This comprehensive book offers readers an engaging journey through its subject matter,
                combining expert knowledge with accessible writing. Perfect for both beginners and
                enthusiasts, it provides valuable insights and practical knowledge that readers can apply
                in their own lives.
              </p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="details" className="mt-6">
          <Card>
            <CardContent className="pt-6">
              <h3 className="text-xl font-semibold mb-4">Product Details</h3>
              <dl className="space-y-3">
                <div className="flex border-b pb-2">
                  <dt className="font-semibold w-32">Author:</dt>
                  <dd className="text-muted-foreground">{book.author}</dd>
                </div>
                <div className="flex border-b pb-2">
                  <dt className="font-semibold w-32">Category:</dt>
                  <dd className="text-muted-foreground">{book.category}</dd>
                </div>
                {book.pages && (
                  <div className="flex border-b pb-2">
                    <dt className="font-semibold w-32">Pages:</dt>
                    <dd className="text-muted-foreground">{book.pages}</dd>
                  </div>
                )}
                {book.publisher && (
                  <div className="flex border-b pb-2">
                    <dt className="font-semibold w-32">Publisher:</dt>
                    <dd className="text-muted-foreground">{book.publisher}</dd>
                  </div>
                )}
                {book.publishedDate && (
                  <div className="flex border-b pb-2">
                    <dt className="font-semibold w-32">Published:</dt>
                    <dd className="text-muted-foreground">{book.publishedDate}</dd>
                  </div>
                )}
                {book.isbn && (
                  <div className="flex border-b pb-2">
                    <dt className="font-semibold w-32">ISBN:</dt>
                    <dd className="text-muted-foreground">{book.isbn}</dd>
                  </div>
                )}
              </dl>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="reviews" className="mt-6">
          <Card>
            <CardContent className="pt-6">
              <h3 className="text-xl font-semibold mb-4">Customer Reviews</h3>
              <div className="space-y-4">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="border-b pb-4 last:border-0">
                    <div className="flex items-center gap-2 mb-2">
                      <div className="flex">
                        {[...Array(5)].map((_, j) => (
                          <Star
                            key={j}
                            className="h-4 w-4 text-yellow-400 fill-current"
                          />
                        ))}
                      </div>
                      <span className="font-semibold">Great book!</span>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      This book exceeded my expectations. Highly recommended for anyone interested in the topic.
                    </p>
                    <p className="text-xs text-muted-foreground mt-2">- Verified Purchase</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Related Books */}
      <div className="mt-12">
        <h2 className="text-2xl font-bold mb-6">You May Also Like</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {mockBooks.filter(b => b.category === book.category && b.id !== book.id).slice(0, 4).map((relatedBook) => (
            <Link key={relatedBook.id} to={`/books/${relatedBook.id}`}>
              <Card className="overflow-hidden hover:shadow-lg transition-shadow">
                <ImageWithFallback
                  src={relatedBook.image}
                  alt={relatedBook.title}
                  className="w-full h-48 object-cover"
                />
                <CardContent className="p-4">
                  <h3 className="font-semibold mb-1 line-clamp-1">{relatedBook.title}</h3>
                  <p className="text-sm text-muted-foreground mb-2">{relatedBook.author}</p>
                  <p className="font-bold">${relatedBook.price}</p>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
